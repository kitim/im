﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.IO.Ports;

namespace Improject_1
{
    public partial class Form1 : Form
    {
        //private SerialPort ardSerialPort = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            //ardSerialPort.PortName = "COM4";
           //ardSerialPort.BaudRate = 9600;
            //ardSerialPort.Open();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
